import java.util.ArrayList;

public class User
{
	public int		id;
	public String	name;
	public boolean	isProfessor;

	public boolean authorize(String login, String password)
	{
		ArrayList<String> result = Main.database.getUsers();
		for (String str : result)
		{
			String[] arr = new String[5];
			arr = str.split(",");
			if (arr.length == 5 && arr[1].equals(login) && arr[2].equals(password))
			{
				this.id = Integer.parseInt(arr[0]);
				this.name = arr[3];
				this.isProfessor = arr[4].equals("1");
				return (true);
			}
		}
		return (false);
	}
}