import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Database
{
	public ArrayList<String>		getUsers()
	{
		String str;

		ArrayList<String> users = new ArrayList<>();
		try
		{
			BufferedReader reader = new BufferedReader(new FileReader("src/database/users.txt"));
			while ((str = reader.readLine()) != null)
				users.add(str.strip());
			reader.close();
		}
		catch (Exception e)
		{
			System.err.println("[getUsers]");
			e.printStackTrace(System.err);
		}
		return (users);
	}

	public ArrayList<Conference>	getConferences()
	{
		ArrayList<Conference> conferences = new ArrayList<>();
		String str;

		try
		{
			BufferedReader reader = new BufferedReader(new FileReader("src/database/indexing.txt"));
			while ((str = reader.readLine()) != null && !str.isEmpty())
			{
				try
				{
					BufferedReader tmpReader = new BufferedReader(new FileReader("src/database/" + str.strip()));
					Conference tmpConference = new Conference();
					tmpConference.id = Integer.parseInt(tmpReader.readLine().strip());
					tmpConference.name = tmpReader.readLine().strip();
					tmpConference.professorId = Integer.parseInt(tmpReader.readLine().strip());

					Calendar calendar = Calendar.getInstance();
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					calendar.setTime(sdf.parse(tmpReader.readLine().strip()));
					tmpConference.date = calendar;

					tmpConference.duration = tmpReader.readLine().strip();
					tmpConference.description = tmpReader.readLine().strip();
					tmpConference.link = tmpReader.readLine().strip();
					tmpConference.participants = new ArrayList<>();
					String participantsStr = tmpReader.readLine();
					if (participantsStr != null && !participantsStr.isEmpty())
					{
						String[] arr = participantsStr.split(":");
						for (String p : arr)
							tmpConference.participants.add(Integer.parseInt(p));
					}
					conferences.add(tmpConference);
					tmpReader.close();
				}
				catch (Exception e)
				{
					System.err.println("[getConferences]");
					e.printStackTrace(System.err);
				}
			}
			reader.close();
		}
		catch (Exception e)
		{
			System.err.println("[getConferences]");
			e.printStackTrace(System.err);
		}
		int i = 0;
		for (Conference c1 : conferences)
		{
			int j = 0;
			for (Conference c2 : conferences)
			{
				if (c2.date.after(c1.date))
				{
					Conference tmp = conferences.get(i);
					conferences.set(i, conferences.get(j));
					conferences.set(j, tmp);
				}
				j++;
			}
			i++;
		}
		return (conferences);
	}

	public ArrayList<User>			getUsersList(ArrayList<String> fileUsers)
	{
		ArrayList<User> users = new ArrayList<>();

		for (String str : fileUsers)
		{
			String[] arr = new String[5];
			arr = str.split(",");
			if (arr.length == 5)
			{
				User user = new User();
				user.id = Integer.parseInt(arr[0]);
				user.name = arr[3];
				user.isProfessor = arr[4].equals("1");
				users.add(user);
			}
		}
		return (users);
	}

	public void						updateParticipants(int conferenceId, ArrayList<Integer> participants)
	{
		StringBuilder str = new StringBuilder();
		StringBuilder stringBuilder = new StringBuilder();

		try
		{
			for (int nbr : participants)
			{
				str.append(nbr);
				str.append(':');
			}
			if (str.length() != 0)
				str.deleteCharAt(str.length() - 1);
			BufferedReader reader = new BufferedReader(new FileReader(String.format("src/database/%d.txt", conferenceId)));
			String tmp;
			for (int i = 0; i < 7; i++)
				stringBuilder.append(reader.readLine()).append("\n");
			stringBuilder.append(str.toString()).append("\n");
			reader.close();
			BufferedWriter writer = new BufferedWriter(new FileWriter(String.format("src/database/%d.txt", conferenceId)));
			writer.write(stringBuilder.toString());
			writer.close();
		}
		catch (Exception e)
		{
			System.err.println("[updateParticipants]");
			e.printStackTrace(System.err);
		}
	}

	public String					getUserName(int id)
	{
		ArrayList<String> res = this.getUsers();

		try
		{
			for (String str : res)
			{
				String[] arr = new String[5];
				arr = str.strip().split(",");
				if (Integer.parseInt(arr[0]) == id)
					return (arr[3]);
			}
		}
		catch (Exception e)
		{
			System.err.println("[getProfessorName]");
			e.printStackTrace();
			System.exit(1);
		}
		return (null);
	}

	public void						addConference(Conference conference)
	{
		StringBuilder str = new StringBuilder();
		boolean check = false;
		if (conference.date.before(Calendar.getInstance()))
			return ;
		if (new File(String.format("src/database/%d.txt", conference.id)).delete())
			check = true;
		try
		{
			for (int nbr : conference.participants)
			{
				str.append(nbr);
				str.append(':');
			}
			if (str.length() != 0)
				str.deleteCharAt(str.length() - 1);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			BufferedWriter writer = new BufferedWriter(new FileWriter(String.format("src/database/%d.txt", conference.id)));
			writer.write(String.format("%d\n%s\n%d\n%s\n%s\n%s\n%s\n%s\n",
					conference.id, conference.name, conference.professorId,
					sdf.format(conference.date.getTime()), conference.duration,
					conference.description, conference.link, str.toString()));
			writer.close();
			StringBuilder stringBuilder = new StringBuilder();
			String tmp;
			BufferedReader reader = new BufferedReader(new FileReader("src/database/indexing.txt"));
			while ((tmp = reader.readLine()) != null)
			{
				stringBuilder.append(tmp).append("\n");
			}
			stringBuilder.append(String.format("%d.txt\n", conference.id));
			reader.close();
			if (!check)
			{
				writer = new BufferedWriter(new FileWriter("src/database/indexing.txt"));
				writer.write(stringBuilder.toString());
				writer.close();
			}
		}
		catch (Exception e)
		{
			System.err.println("[editConference]");
			e.printStackTrace(System.err);
		}
	}

	public void						deleteConference(int id)
	{
		if (!(new File(String.format("src/database/%d.txt", id))).delete())
			return ;
		try
		{
			StringBuilder stringBuilder = new StringBuilder();
			String tmp;

			BufferedReader reader = new BufferedReader(new FileReader("src/database/indexing.txt"));
			while ((tmp = reader.readLine()) != null)
			{
				if (!tmp.strip().equals(String.format("%d.txt", id)))
					stringBuilder.append(tmp).append("\n");
			}
			reader.close();
			BufferedWriter writer = new BufferedWriter(new FileWriter("src/database/indexing.txt"));
			writer.write(stringBuilder.toString());
			writer.close();
		}
		catch (Exception e)
		{
			System.err.println("[deleteConference]");
			e.printStackTrace(System.err);
		}
	}
}
